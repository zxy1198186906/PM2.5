package app.services;

/**
 * Created by liuhaodong1 on 16/6/13.
 */
public class AffliatedService {

}
