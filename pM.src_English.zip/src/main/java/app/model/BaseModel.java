package app.model;

import java.io.Serializable;

/**
 * Created by liuhaodong1 on 15/11/9.
 */
public class BaseModel implements Serializable {

}
